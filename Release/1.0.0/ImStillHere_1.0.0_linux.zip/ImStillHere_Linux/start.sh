#!/bin/bash

java -jar imStillHere.jar